

==============================================================
Readme file for:

Hauner (2020) “Aggregate wealth and its distribution as determinants of financial crises”
Journal of Economic Inequality

==============================================================


.zip file contains the following:


1) WineqInstability_raw_data.zip
===============================
This file itself contains 3 data files for replicating all data in the paper:

- ineqInstability_Wpanel.xlsx (tab “data_2.0”)
- PR_finsh.dta
- JSTdatasetR3.dta

Tab “sources” in the .xlsx file contains detailed variable definitions and source info.



2) WineqInstability_data.do
===============================
This file recreates the .dta file used in the estimation file, ineqInstability_Wpanel_v2.dta.



3) WineqInstability_est.do
===============================
This file recreates the main LPM regression models, forecasts and predications, and robustness checks in the paper.


NOTE: all file directories must be edited/updated in each script to point to the user’s file locations.
